/****************************************
/* Author: Teacher
/* Course: CSC 221, Fall 2023
/* Lab: Inheritance Group Lab
/* Modified: October 29th 2023
/* Modified by Nick Bohm,MicahYoder,Nathan Kropiewnicki
*****************************************/
import java.io.*;
import java.util.*;
public class GameDrive {
    public static void main(String[] args) {
        TicTacToeGame tttGame;
        ReversiGame RGame;
        Connect4Game CGame;
        CheckersGame ChGame;
        InputOutput scanner;
        int choice, size, answer;
        scanner  = new InputOutput();
        String filename;
        System.out.println("press 1 for tictactoe");
        System.out.println("press 2 for Reversi");
        System.out.println("press 3 for connect4");
        System.out.println("press 4 for checkers");
        answer = scanner.nextInt();
        if(answer == 1){
            System.out.println("press 1 for a default board");
            System.out.println("press 2 for a custom board");
            answer = scanner.nextInt();
        }
        if(answer == 1){
            tttGame = new TicTacToeGame();
            tttGame.playGame();
        }
        else if(answer == 2){
            RGame = new ReversiGame();
            RGame.playGame();
        }  
        else if(answer == 3){
            CGame = new Connect4Game();
            CGame.playGame();
        }
        else if(answer == 4){
            ChGame= new CheckersGame(8);
            ChGame.playGame();
        }      
           
        
    }
}  
