/****************************************
/* Author: Nathan Kropiewnicki
/* Course: CSC 221, Fall 2023
/* Lab: Inheritance Group Lab
/* Modified: October 29th 2023
*****************************************/
public class CheckersGame extends Game{
    private CheckersBoard cBoard;
    private Player bPlayer, rPlayer;
    private InputOutput ioDevice;
    
    public CheckersGame() {
        ioDevice = new InputOutput();
        cBoard = new CheckersBoard();
        ioDevice.print("What is the name of the X player? ");
        bPlayer = new Player(ioDevice.nextString(),new Piece(Piece.B));
        ioDevice.flushLine();
        ioDevice.print("What is the name of the O player? ");
        rPlayer = new Player(ioDevice.nextString(),new Piece(Piece.R));
        ioDevice.flushLine();
    }
    
    public CheckersGame(int size) {
        ioDevice = new InputOutput();
        cBoard = new CheckersBoard(size);
        ioDevice.print("What is the name of player 1? ");
        bPlayer = new Player(ioDevice.nextString(),new Piece(Piece.B));
        ioDevice.flushLine();
        ioDevice.print("What is the name of player 2? ");
        rPlayer = new Player(ioDevice.nextString(),new Piece(Piece.R));
        ioDevice.flushLine();
    }

    public CheckersGame(String filename) {
        int size;
        String str;
        ioDevice = new InputOutput(filename);
        size = ioDevice.nextInt();
        cBoard = new CheckersBoard(size);
        ioDevice.flushLine();
        bPlayer = new Player(ioDevice.nextString(),new Piece(Piece.B));
        ioDevice.flushLine();
        rPlayer = new Player(ioDevice.nextString(),new Piece(Piece.R));
        ioDevice.flushLine();
    }

    public void playGame() {
        Player currentPlayer;
        Move move;
        int moveRow, moveCol;
        currentPlayer = bPlayer;
        //initializing b side of board
        move = new Move(5,1);
        cBoard.makeMove(move, bPlayer);
        move = new Move(5,3);
        cBoard.makeMove(move, bPlayer);
        move = new Move(5,5);
        cBoard.makeMove(move, bPlayer);
        move = new Move(5,7);
        cBoard.makeMove(move, bPlayer);
        move = new Move(6,0);
        cBoard.makeMove(move, bPlayer);
        move = new Move(6,2);
        cBoard.makeMove(move, bPlayer);
        move = new Move(6,4);
        cBoard.makeMove(move, bPlayer);
        move = new Move(6,6);
        cBoard.makeMove(move, bPlayer);
        move = new Move(7,1);
        cBoard.makeMove(move, bPlayer);
        move = new Move(7,3);
        cBoard.makeMove(move, bPlayer);
        move = new Move(7,5);
        cBoard.makeMove(move, bPlayer);
        move = new Move(7,7);
        cBoard.makeMove(move, bPlayer);
        //initializing r side of board
        move = new Move(0,0);
        cBoard.makeMove(move, rPlayer);
        move = new Move(0,2);
        cBoard.makeMove(move, rPlayer);
        move = new Move(0,4);
        cBoard.makeMove(move, rPlayer);
        move = new Move(0,6);
        cBoard.makeMove(move, rPlayer);
        move = new Move(1,1);
        cBoard.makeMove(move, rPlayer);
        move = new Move(1,3);
        cBoard.makeMove(move, rPlayer);
        move = new Move(1,5);
        cBoard.makeMove(move, rPlayer);
        move = new Move(1,7);
        cBoard.makeMove(move, rPlayer);
        move = new Move(2,0);
        cBoard.makeMove(move, rPlayer);
        move = new Move(2,2);
        cBoard.makeMove(move, rPlayer);
        move = new Move(2,4);
        cBoard.makeMove(move, rPlayer);
        move = new Move(2,6);
        cBoard.makeMove(move, rPlayer);
        while (!gameOver()) {
            displayBoard();
            System.out.println("What piece do you wish to move?");
            moveRow = ioDevice.nextInt();
            moveCol = ioDevice.nextInt();
            move = new Move(moveRow, moveCol);
            while (!cBoard.legalPiece(move)) {
                ioDevice.println("Illegal move");
                System.out.println("What piece do you wish to move?");
            moveRow = ioDevice.nextInt();
            moveCol = ioDevice.nextInt();
            }
            move = super.getMove(currentPlayer);
            
            while (!cBoard.legalMove(move)) {
                ioDevice.println("Illegal move");
                move = super.getMove(currentPlayer);
            }
            cBoard.makeMove(move, currentPlayer);
            if (currentPlayer == bPlayer) currentPlayer = rPlayer;
            else currentPlayer = bPlayer;
        }
        
        if (cBoard.winner(bPlayer)) 
            ioDevice.println(bPlayer.getName()+" is the winner.");
        else ioDevice.println(rPlayer.getName()+" is the winner.");
    }
    
    private boolean gameOver() {
        if (cBoard.winner(bPlayer) || cBoard.winner(rPlayer)) return false;
        return false;
    }
    private void displayBoard() {
        ioDevice.print(cBoard.toString());
    }

}